'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import type { Lead, Goal, Notification } from '@/types'
import Topbar from '@/components/dashboard/Topbar'
import Sidebar from '@/components/dashboard/Sidebar'
import OverviewTab from '@/components/dashboard/OverviewTab'
import LeadsTab from '@/components/dashboard/LeadsTab'
import GoalsTab from '@/components/dashboard/GoalsTab'
import NotificationsPanel from '@/components/dashboard/NotificationsPanel'

export type Tab = 'overview' | 'leads' | 'goals'

export default function Dashboard() {
  const [tab, setTab] = useState<Tab>('overview')
  const [user, setUser] = useState<any>(null)
  const [leads, setLeads] = useState<Lead[]>([])
  const [goals, setGoals] = useState<Goal[]>([])
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [notifOpen, setNotifOpen] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) { router.push('/auth'); return }
      setUser(user)
      loadData(user.id)
    })
  }, [])

  async function loadData(uid: string) {
    const [{ data: l }, { data: g }, { data: n }] = await Promise.all([
      supabase.from('leads').select('*').eq('user_id', uid).order('created_at', { ascending: false }),
      supabase.from('goals').select('*').eq('user_id', uid).order('created_at', { ascending: false }),
      supabase.from('notifications').select('*').eq('user_id', uid).order('created_at', { ascending: false }).limit(20),
    ])
    if (l) setLeads(l)
    if (g) setGoals(g)
    if (n) setNotifications(n)
  }

  async function addLead(lead: Omit<Lead, 'id' | 'user_id' | 'created_at'>) {
    const { data } = await supabase.from('leads').insert({ ...lead, user_id: user.id }).select().single()
    if (data) {
      setLeads(prev => [data, ...prev])
      if (lead.stage === 'hot') addNotification(`New hot lead: ${lead.company} ($${lead.acv.toLocaleString()})`, 'success')
    }
  }

  async function wonLead(id: string, company: string, acv: number) {
    await supabase.from('leads').update({ stage: 'won' }).eq('id', id)
    setLeads(prev => prev.map(l => l.id === id ? { ...l, stage: 'won' } : l))
    addNotification(`Deal won: ${company} — $${acv.toLocaleString()} 🎉`, 'success')
  }

  async function addGoal(goal: Omit<Goal, 'id' | 'user_id' | 'created_at'>) {
    const { data } = await supabase.from('goals').insert({ ...goal, user_id: user.id }).select().single()
    if (data) {
      setGoals(prev => [data, ...prev])
      if (goal.progress === 100) addNotification(`Goal completed: ${goal.name}`, 'success')
    }
  }

  async function addNotification(title: string, type: Notification['type']) {
    const { data } = await supabase.from('notifications').insert({ user_id: user.id, title, type, read: false }).select().single()
    if (data) setNotifications(prev => [data, ...prev])
  }

  async function markAllRead() {
    await supabase.from('notifications').update({ read: true }).eq('user_id', user.id)
    setNotifications(prev => prev.map(n => ({ ...n, read: true })))
  }

  async function logout() {
    await supabase.auth.signOut()
    router.push('/auth')
  }

  const unreadCount = notifications.filter(n => !n.read).length

  if (!user) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-sm text-gray-400 animate-pulse">Loading GrowthOS…</div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <Topbar
        user={user}
        unreadCount={unreadCount}
        onNotifClick={() => setNotifOpen(o => !o)}
        onLogout={logout}
      />
      {notifOpen && (
        <NotificationsPanel
          notifications={notifications}
          onMarkAllRead={markAllRead}
          onClose={() => setNotifOpen(false)}
        />
      )}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <Sidebar tab={tab} setTab={setTab} />
        {tab === 'overview' && <OverviewTab leads={leads} goals={goals} />}
        {tab === 'leads' && <LeadsTab leads={leads} onAdd={addLead} onWon={wonLead} />}
        {tab === 'goals' && <GoalsTab goals={goals} onAdd={addGoal} />}
      </div>
    </div>
  )
}
